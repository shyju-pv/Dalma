import Link from "next/link";
import Image from "next/image";
import type { ReactNode } from "react";
import { JsonLd } from "./JsonLd";
import { breadcrumbJsonLd } from "@/lib/seo";
import { getPackages, getTx, getWa, type Post, type Treatment, type Pack } from "@/lib/data";
import { hrefTo, intlLocale, type Locale } from "@/lib/i18n";

export const Sparkle = ({ size = 24 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" aria-hidden="true"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z" /><path d="M19 15l.7 1.8 1.8.7-1.8.7L19 20l-.7-1.8-1.8-.7 1.8-.7z" /></svg>
);

export function Hero({ eyebrow, line1, line2, text, children }: { eyebrow: string; line1: string; line2?: string; text?: string; children?: ReactNode }) {
  return (
    <div className="w page"><div className="hero">
      <div className="ic"><Sparkle /></div><div className="eb">{eyebrow}</div>
      <h1>{line1}{line2 && <span>{line2}</span>}</h1>
      {text && <p>{text}</p>}
      {children && <div className="cta">{children}</div>}
    </div></div>
  );
}

export const Section = ({ children, alt }: { children: ReactNode; alt?: boolean }) => (<section className={alt ? "alt" : undefined}><div className="w">{children}</div></section>);
export const Heading = ({ title, text }: { title: string; text?: string }) => (<div className="sh"><h2>{title}</h2>{text && <p>{text}</p>}</div>);

export async function Crumbs({ l, items }: { l: Locale; items: { name: string; path: string }[] }) {
  const tx = await getTx(l);
  return (
    <>
      <JsonLd data={breadcrumbJsonLd([{ name: tx("nav.home"), path: `/${l}` }, ...items.map((i) => ({ name: i.name, path: `/${l}${i.path}` }))])} />
      <div className="crumbs" role="navigation" aria-label="Breadcrumb"><Link href={hrefTo(l)}>{tx("nav.home")}</Link>{items.map((i) => <span key={i.path}> / <Link href={hrefTo(l, i.path)}>{i.name}</Link></span>)}</div>
    </>
  );
}

export async function CtaBand({ l }: { l: Locale }) {
  const tx = await getTx(l);
  return <Section><div className="band"><h2>{tx("cta.t")}</h2><p>{tx("cta.d")}</p><Link className="btn" href={hrefTo(l, "/appointment")}>{tx("nav.book")}</Link></div></Section>;
}

export function Faq({ items }: { items: { q: string; a: string }[] }) {
  return (
    <div className="faq">
      <JsonLd data={{ "@context": "https://schema.org", "@type": "FAQPage", mainEntity: items.map((i) => ({ "@type": "Question", name: i.q, acceptedAnswer: { "@type": "Answer", text: i.a } })) }} />
      {items.map((i) => <details key={i.q}><summary>{i.q}</summary><p>{i.a}</p></details>)}
    </div>
  );
}

export async function TreatmentCards({ l, items }: { l: Locale; items: Treatment[] }) {
  const tx = await getTx(l);
  return (
    <div className="grid">
      {items.map((t) => (
        <Link key={t.slug} className="card" href={hrefTo(l, `/treatments/${t.slug}`)}>
          {t.image && <div className="img" style={{ position: "relative" }}><Image src={t.image} alt={t.name} fill sizes="(max-width:860px) 100vw, 360px" style={{ objectFit: "cover" }} /></div>}
          <span className="tag">{t.subtitle}</span><h3>{t.name}</h3><p>{t.summary.split(/(?<=[.。])\s/)[0]}</p><span className="more">{tx("c.details")}</span>
        </Link>
      ))}
    </div>
  );
}

export async function PackageCards({ l, items }: { l: Locale; items?: Pack[] }) {
  const [list, tx, wa] = await Promise.all([items ?? getPackages(l), getTx(l), getWa(l)]);
  return (
    <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))" }}>
      {list.map((p) => (
        <div className="card" key={p.id}><span className="tag">{p.tag}</span><h3>{p.name}</h3><p>{p.text}</p>
          <p><a className="btn o sm" href={wa(tx("wa.pk", { name: p.name }))} rel="noopener noreferrer">{tx("c.wa")}</a></p></div>
      ))}
    </div>
  );
}

const split = (t: string): [string, string] => { const w = t.split(" "); if (w.length < 4) return [t, ""]; const m = Math.ceil(w.length / 2); return [w.slice(0, m).join(" "), w.slice(m).join(" ")]; };

const Leaf = () => (
  <svg className="dc" viewBox="0 0 200 200" aria-hidden="true"><path d="M10 200C0 150 20 100 70 70C80 120 60 170 10 200Z" fill="#6E9A6B" /><path d="M60 200C50 160 70 120 110 100C115 140 100 175 60 200Z" fill="#8FB58A" /><path d="M95 150H195A50 40 0 0 1 95 150Z" fill="#D9D2C0" /><path d="M110 148Q145 118 180 148Z" fill="#B88A44" /><ellipse cx="145" cy="150" rx="50" ry="6" fill="#B8A98A" /></svg>
);

export function Cover({ post, pill }: { post: Post; pill?: boolean }) {
  const [a, b] = split(post.title);
  return (
    <div className="cv">
      {post.image ? <Image src={post.image} alt={post.title} fill sizes="(max-width:860px) 100vw, 360px" style={{ objectFit: "cover" }} /> : (
        <><Leaf /><div className="cvt"><span className="h4">{a}<span>{b}</span></span><small>{post.tagline}</small></div></>
      )}
      {pill && <><span className="pill">{post.category}</span><span className="ar" aria-hidden="true">↗</span></>}
    </div>
  );
}

export const Meta = ({ post, l, min }: { post: Post; l: Locale; min: string }) => (
  <div className="meta"><time dateTime={post.date}>{new Date(post.date).toLocaleDateString(intlLocale(l), { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" })}</time><span>•</span><span>{post.minutes} {min}</span></div>
);

export async function BlogCards({ l, posts }: { l: Locale; posts: Post[] }) {
  const tx = await getTx(l);
  return (
    <div className="grid">
      {posts.map((p) => (
        <Link key={p.slug} className="bc" href={hrefTo(l, `/blog/${p.slug}`)}>
          <Cover post={p} pill />
          <div className="bb"><Meta post={p} l={l} min={tx("c.min")} /><h3>{p.title}</h3><p>{p.excerpt}</p><div className="rd">{tx("c.read")} ↗</div></div>
        </Link>
      ))}
    </div>
  );
}
