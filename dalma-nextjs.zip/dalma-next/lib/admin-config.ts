// Describes what the admin can edit. Adding a field here (plus a column in Supabase) adds it to the admin form.
export type FieldType = "text" | "textarea" | "lines" | "image" | "bool" | "date" | "number" | "slug";
export type Field = { key: string; label: string; type: FieldType; bi?: boolean; hint?: string; required?: boolean };
export type Resource = { table: string; title: string; single?: boolean; order: string; listKey: string; slugFrom?: string; fields: Field[] };

export const resources: Record<string, Resource> = {
  blog: {
    table: "blog_posts", title: "Blog posts", order: "published_at", listKey: "title_en", slugFrom: "title_en",
    fields: [
      { key: "slug", label: "URL slug", type: "slug", hint: "Leave empty to create it from the English title." },
      { key: "title", label: "Title", type: "text", bi: true, required: true },
      { key: "category", label: "Category", type: "text", bi: true },
      { key: "tagline", label: "Cover tagline", type: "text", bi: true, hint: "Short line shown on the illustrated cover." },
      { key: "excerpt", label: "Short summary", type: "textarea", bi: true, hint: "Used on cards and in Google results (about 150 characters)." },
      { key: "body", label: "Article text", type: "textarea", bi: true, hint: "Separate paragraphs with a blank line." },
      { key: "cover_url", label: "Cover photo", type: "image" },
      { key: "minutes", label: "Minutes to read", type: "number" },
      { key: "published_at", label: "Publish date", type: "date" },
      { key: "published", label: "Published", type: "bool" },
    ],
  },
  treatments: {
    table: "treatments", title: "Treatments", order: "sort", listKey: "name_en", slugFrom: "name_en",
    fields: [
      { key: "slug", label: "URL slug", type: "slug" },
      { key: "name", label: "Name", type: "text", bi: true, required: true },
      { key: "subtitle", label: "Subtitle", type: "text", bi: true },
      { key: "summary", label: "Description", type: "textarea", bi: true },
      { key: "benefits", label: "Benefits", type: "lines", bi: true, hint: "One per line." },
      { key: "image_url", label: "Photo", type: "image" },
      { key: "sort", label: "Order (1 = first)", type: "number" },
      { key: "published", label: "Published", type: "bool" },
    ],
  },
  packages: {
    table: "packages", title: "Packages", order: "sort", listKey: "name_en",
    fields: [
      { key: "name", label: "Name", type: "text", bi: true, required: true },
      { key: "tag", label: "Label", type: "text", bi: true },
      { key: "text", label: "Description", type: "textarea", bi: true },
      { key: "sort", label: "Order (1 = first)", type: "number" },
      { key: "published", label: "Published", type: "bool" },
    ],
  },
  settings: {
    table: "site_settings", title: "Contact settings", single: true, order: "id", listKey: "phone",
    fields: [
      { key: "phone", label: "Landline (with +971)", type: "text" },
      { key: "mobile", label: "Mobile (with +971)", type: "text" },
      { key: "whatsapp", label: "WhatsApp number (digits only, e.g. 971509678737)", type: "text" },
      { key: "email", label: "Email", type: "text" },
      { key: "facebook", label: "Facebook URL", type: "text" },
      { key: "instagram", label: "Instagram URL", type: "text" },
      { key: "po_box", label: "P.O. Box", type: "text" },
      { key: "address", label: "Address", type: "text", bi: true },
      { key: "landmark", label: "Landmark", type: "text", bi: true },
    ],
  },
};

export const columns = (f: Field) => (f.bi ? [`${f.key}_en`, `${f.key}_ar`] : [f.key]);
export const slugify = (s: string) => s.toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
