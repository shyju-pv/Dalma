import Link from "next/link";
import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { getPackages, getPosts, getSettings, getTreatments, getTx } from "@/lib/data";
import { asLocale, hrefTo } from "@/lib/i18n";
import { BlogCards, CtaBand, Faq, Heading, Hero, PackageCards, Section, Sparkle, TreatmentCards } from "@/components/site/ui";

type P = { params: Promise<{ locale: string }> };
export async function generateMetadata({ params }: P): Promise<Metadata> {
  const l = asLocale((await params).locale); const tx = await getTx(l);
  return pageMeta(l, "/", tx("m.home.t") + " | " + tx("brand"), tx("m.home.d"), { absolute: true });
}

export default async function Home({ params }: P) {
  const l = asLocale((await params).locale);
  const [tx, s, tr, pk, posts] = await Promise.all([getTx(l), getSettings(l), getTreatments(l), getPackages(l), getPosts(l)]);
  const faqs = [1, 2, 3, 4].map((n) => ({ q: tx(`faq.q${n}`), a: tx(`faq.a${n}`, { address: `${s.address} (${s.landmark})`, phone: s.phone }) }));
  return (
    <>
      <Hero eyebrow={tx("home.eb")} line1={tx("home.l1")} line2={tx("home.l2")} text={tx("home.d")}>
        <Link className="btn" href={hrefTo(l, "/appointment")}>{tx("nav.book")}</Link><Link className="btn o" href={hrefTo(l, "/treatments")}>{tx("c.explore")}</Link>
      </Hero>
      <Section alt>
        <div className="two"><div><div className="eb">{tx("home.w.eb")}</div><h2>{tx("home.w.t")}</h2><p>{tx("home.w.p1")}</p><p>{tx("home.w.p2")}</p><Link className="btn" href={hrefTo(l, "/about-us")}>{tx("c.learn")}</Link></div>
          <div className="pic"><Sparkle size={64} /></div></div>
      </Section>
      <Section><Heading title={tx("home.sig.t")} text={tx("home.sig.d")} /><TreatmentCards l={l} items={tr.slice(0, 6)} />
        <p style={{ textAlign: "center", marginTop: 32 }}><Link className="btn o" href={hrefTo(l, "/treatments")}>{tx("c.all")}</Link></p></Section>
      <Section alt><Heading title={tx("home.cond.t")} text={tx("home.cond.d")} />
        <div className="grid">{[1, 2, 3].map((n) => <div className="card" key={n}><h3>{tx(`cond.${n}`)}</h3><ul className="chips" style={{ padding: 0 }}>{tx(`cond.${n}.i`).split("|").map((i) => <li key={i}>{i}</li>)}</ul></div>)}</div></Section>
      <Section><Heading title={tx("home.pk.t")} text={tx("home.pk.d")} /><PackageCards l={l} items={pk} />
        <p style={{ textAlign: "center", marginTop: 32 }}><Link className="btn o" href={hrefTo(l, "/packages")}>{tx("c.seepk")}</Link></p></Section>
      <Section alt>
        <div className="jh"><div><span className="pillx">{tx("home.j.pill")}</span><h2>{tx("home.j.t1")}<span>{tx("home.j.t2")}</span></h2><p>{tx("home.j.d")}</p></div><Link className="vl" href={hrefTo(l, "/blog")}>{tx("home.j.all")}</Link></div>
        <BlogCards l={l} posts={posts.slice(0, 3)} />
      </Section>
      <Section><Heading title={tx("home.faq.t")} /><div style={{ maxWidth: 760, margin: "0 auto" }}><Faq items={faqs} /></div></Section>
      <CtaBand l={l} />
    </>
  );
}
